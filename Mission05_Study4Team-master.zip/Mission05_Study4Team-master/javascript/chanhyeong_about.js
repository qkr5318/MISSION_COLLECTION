$("document").ready(function() {
  var options = { 
      videoId: 'UsqawnamY94', 
      start: 3 
    };

    $('#wrapper').tubular(options);

});
