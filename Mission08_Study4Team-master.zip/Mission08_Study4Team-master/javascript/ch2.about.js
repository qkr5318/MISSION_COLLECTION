$("document").ready(function() {
    var options = { 
        videoId: '8YE7o5hrkQc', 
        start: 3 
      };
  
      $('#wrapper').tubular(options);
  
  });
  